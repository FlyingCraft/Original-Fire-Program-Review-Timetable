"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { BarChart3, RefreshCw, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

const DAYS = [
  { date: "2026-09-25", weekday: "周五", label: "9月25日" },
  { date: "2026-09-26", weekday: "周六", label: "9月26日" },
  { date: "2026-09-27", weekday: "周日", label: "9月27日" },
] as const;
const TIMES = Array.from({ length: 28 }, (_, index) => {
  const minutes = 8 * 60 + index * 30;
  return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
});
const slotKey = (date: string, time: string) => `${date}T${time}`;
const endTime = (time: string) => {
  const [hour, minute] = time.split(":").map(Number);
  const total = hour * 60 + minute + 30;
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
};
type ResponseRow = { id: string; name: string; groupName: string; note: string; slots: string[]; updatedAt: string };

function heat(count: number, max: number) {
  if (!count) return "heat-0";
  const ratio = count / Math.max(max, 1);
  if (ratio > .8) return "heat-5";
  if (ratio > .6) return "heat-4";
  if (ratio > .4) return "heat-3";
  if (ratio > .2) return "heat-2";
  return "heat-1";
}

export default function StatsPage() {
  const [responses, setResponses] = useState<ResponseRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSlot, setActiveSlot] = useState<string | null>(null);
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/responses", { cache: "no-store" });
      const data = (await response.json()) as { responses?: ResponseRow[] };
      setResponses(data.responses ?? []);
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const counts = useMemo(() => {
    const result = new Map<string, number>();
    responses.forEach((person) => person.slots.forEach((slot) => result.set(slot, (result.get(slot) ?? 0) + 1)));
    return result;
  }, [responses]);
  const maxCount = Math.max(0, ...counts.values());
  const activePeople = activeSlot ? responses.filter((person) => person.slots.includes(activeSlot)) : [];
  const activeDay = activeSlot ? DAYS.find((day) => activeSlot.startsWith(day.date)) : null;

  return (
    <main className="site stats-site">
      <header className="topbar">
        <div className="brand-mark"><BarChart3 size={20} /></div>
        <div><p className="eyebrow">ORGANIZER VIEW</p><h1>节目审核 · 到场统计</h1></div>
        <div className="total-pill"><Users size={16} />{responses.length} 份提交</div>
      </header>
      <div className="stats-shell">
        <section className="stats-card">
          <div className="stats-title">
            <div><h2>各时段可到场人数</h2><p>颜色越深，人数越多。点击格子查看名单。</p></div>
            <Button variant="outline" size="sm" onClick={() => void load()}><RefreshCw className={loading ? "animate-spin" : ""} />刷新</Button>
          </div>
          <div className="heat-wrap">
            <div className="heat-grid">
              <div className="corner">时间</div>
              {DAYS.map((day) => <div className="date-head" key={day.date}><span>{day.weekday}</span><strong>{day.label}</strong></div>)}
              {TIMES.map((time, index) => (
                <div className="heat-row" key={time}>
                  <div className={`time-label ${index % 2 ? "half" : ""}`}>{index % 2 === 0 ? time : ""}</div>
                  {DAYS.map((day) => {
                    const slot = slotKey(day.date, time);
                    const count = counts.get(slot) ?? 0;
                    return <button key={slot} onClick={() => setActiveSlot(slot)} className={`heat-cell ${heat(count, maxCount)} ${activeSlot === slot ? "active" : ""}`} aria-label={`${day.label} ${time}，${count}人可到场`}><strong>{count || ""}</strong></button>;
                  })}
                </div>
              ))}
              <div className="end-label">22:00</div>
            </div>
          </div>
        </section>

        <aside className="roster-card">
          {activeSlot ? <>
            <p className="eyebrow">所选时段</p>
            <h2>{activeDay?.label}</h2>
            <h3>{activeSlot.slice(11)}—{endTime(activeSlot.slice(11))}</h3>
            <div className="roster-count"><strong>{activePeople.length}</strong><span>人可到场</span></div>
            <div className="people-list">{activePeople.map((person) => <div key={person.id}><span>{person.name.slice(0, 1)}</span><div><strong>{person.name}</strong><small>{person.groupName || "未填写组别"}{person.note ? ` · ${person.note}` : ""}</small></div></div>)}</div>
          </> : <div className="roster-empty"><BarChart3 /><h2>选择一个时段</h2><p>点击左侧表格中的数字，可查看对应人员。</p></div>}
        </aside>
      </div>
    </main>
  );
}
