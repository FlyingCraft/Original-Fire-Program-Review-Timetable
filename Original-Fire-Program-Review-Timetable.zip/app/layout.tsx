import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "节目审核时间统计",
  description: "统计 9 月 25—27 日成员可到场参与节目审核的时间",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
