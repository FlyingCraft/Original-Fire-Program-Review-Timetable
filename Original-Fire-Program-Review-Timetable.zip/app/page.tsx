"use client";

import { useCallback, useEffect, useState } from "react";
import { CalendarDays, Check, Clock3, RefreshCw, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Toaster } from "@/components/ui/sonner";

const DAYS = [
  { date: "2026-09-25", weekday: "周五", label: "9月25日" },
  { date: "2026-09-26", weekday: "周六", label: "9月26日" },
  { date: "2026-09-27", weekday: "周日", label: "9月27日" },
] as const;
const TIMES = Array.from({ length: 28 }, (_, index) => {
  const minutes = 8 * 60 + index * 30;
  return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
});
const slotKey = (date: string, time: string) => `${date}T${time}`;
const endTime = (time: string) => {
  const [hour, minute] = time.split(":").map(Number);
  const total = hour * 60 + minute + 30;
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
};
type ResponseRow = { id: string; name: string; groupName: string; note: string; slots: string[]; updatedAt: string };

export default function Home() {
  const [name, setName] = useState("");
  const [groupName, setGroupName] = useState("");
  const [note, setNote] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [responseId, setResponseId] = useState("");
  const [editToken, setEditToken] = useState("");
  const [saving, setSaving] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const loadOwnResponse = useCallback(async (id: string) => {
    try {
      const response = await fetch("/api/responses", { cache: "no-store" });
      if (!response.ok) return;
      const data = (await response.json()) as { responses: ResponseRow[] };
      const own = data.responses.find((item) => item.id === id);
      if (!own) return;
      setName(own.name); setGroupName(own.groupName); setNote(own.note); setSelected(new Set(own.slots));
    } catch { /* keep the blank form usable */ }
  }, []);

  useEffect(() => {
    const id = window.localStorage.getItem("review-response-id") ?? "";
    setResponseId(id);
    setEditToken(window.localStorage.getItem("review-edit-token") ?? "");
    if (id) void loadOwnResponse(id);
  }, [loadOwnResponse]);

  function toggle(slot: string) {
    setSelected((current) => { const next = new Set(current); next.has(slot) ? next.delete(slot) : next.add(slot); return next; });
  }

  async function submit() {
    if (!name.trim()) return toast.error("请先填写姓名");
    if (!selected.size) return toast.error("请至少选择一个可到场时段");
    setSaving(true);
    try {
      const response = await fetch("/api/responses", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: responseId || undefined, editToken: editToken || undefined, name: name.trim(), groupName: groupName.trim(), note: note.trim(), slots: [...selected].sort() }),
      });
      const data = (await response.json()) as { response?: ResponseRow; editToken?: string; error?: string };
      if (!response.ok || !data.response || !data.editToken) throw new Error(data.error ?? "save failed");
      setResponseId(data.response.id); setEditToken(data.editToken);
      window.localStorage.setItem("review-response-id", data.response.id);
      window.localStorage.setItem("review-edit-token", data.editToken);
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch { toast.error("保存失败，请稍后再试"); }
    finally { setSaving(false); }
  }

  return (
    <main className="site">
      <Toaster position="top-center" richColors />
      <header className="topbar">
        <div className="brand-mark"><CalendarDays size={20} /></div>
        <div><p className="eyebrow">PROGRAM REVIEW</p><h1>节目审核时间统计</h1></div>
      </header>

      <div className="form-shell">
        {submitted && (
          <section className="success-card">
            <span><Check size={23} /></span>
            <div><strong>{responseId ? "时间已保存" : "提交成功"}</strong><p>负责人会根据整体情况另行通知审核安排。</p></div>
            <button onClick={() => setSubmitted(false)}>继续修改</button>
          </section>
        )}

        <section className="intro-card">
          <div className="date-line"><span>SEP</span><strong>25—27</strong><em>2026</em></div>
          <div><h2>勾选所有能够到场的时间</h2><p>每格代表 30 分钟，可以跨日期、跨时段多选。提交后仍可在本设备修改。</p></div>
        </section>

        <section className="form-card">
          <div className="section-heading"><span className="step">01</span><h2>你的信息</h2>{responseId && <small><Check size={13} />已找到此前提交</small>}</div>
          <div className="identity-grid">
            <label><span>姓名 <b>*</b></span><Input value={name} maxLength={30} onChange={(e) => setName(e.target.value)} placeholder="怎么称呼你" /></label>
            <label><span>节目 / 组别</span><Input value={groupName} maxLength={50} onChange={(e) => setGroupName(e.target.value)} placeholder="选填，便于负责人识别" /></label>
          </div>

          <div className="section-heading slots-heading"><span className="step">02</span><h2>可到场时段</h2><small>已选 {selected.size} 格 · 共 {selected.size * 30} 分钟</small></div>
          <div className="picker-wrap">
            <div className="time-picker">
              <div className="corner">时间</div>
              {DAYS.map((day) => <div className="date-head" key={day.date}><span>{day.weekday}</span><strong>{day.label}</strong></div>)}
              {TIMES.map((time, index) => (
                <div className="picker-row" key={time}>
                  <div className={`time-label ${index % 2 ? "half" : ""}`}>{index % 2 === 0 ? time : ""}</div>
                  {DAYS.map((day) => {
                    const slot = slotKey(day.date, time);
                    const checked = selected.has(slot);
                    return <button key={slot} className={`pick-cell ${checked ? "selected" : ""}`} aria-pressed={checked} aria-label={`${day.label} ${time} 至 ${endTime(time)}`} onClick={() => toggle(slot)}>{checked && <Check size={17} strokeWidth={3} />}</button>;
                  })}
                </div>
              ))}
              <div className="end-label">22:00</div>
            </div>
          </div>

          <label className="note-field"><span>补充说明</span><textarea value={note} maxLength={200} onChange={(e) => setNote(e.target.value)} placeholder="例如：19:30 后才能到、需要提前离场……" /></label>
          <div className="submit-row">
            <p><Clock3 size={16} />请尽量多选，方便安排共同时间</p>
            <Button className="submit-button" size="lg" disabled={saving} onClick={submit}>{saving ? <RefreshCw className="animate-spin" /> : <Send />}{responseId ? "更新我的时间" : "提交可用时间"}</Button>
          </div>
        </section>
      </div>
    </main>
  );
}
