import { desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { responses } from "@/db/schema";

export const dynamic = "force-dynamic";
const VALID_DATES = new Set(["2026-09-25", "2026-09-26", "2026-09-27"]);

function publicRow(row: typeof responses.$inferSelect) {
  let slots: string[] = [];
  try { slots = JSON.parse(row.slotsJson) as string[]; } catch { slots = []; }
  return { id: row.id, name: row.name, groupName: row.groupName, note: row.note, slots, updatedAt: row.updatedAt };
}
function validSlot(value: unknown): value is string {
  return typeof value === "string" && /^2026-09-2[5-7]T(?:0[8-9]|1\d|2[01]):(?:00|30)$/.test(value) && VALID_DATES.has(value.slice(0, 10));
}
async function hashToken(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function GET() {
  try {
    const rows = await getDb().select().from(responses).orderBy(desc(responses.updatedAt)).limit(500);
    return Response.json({ responses: rows.map(publicRow) }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("responses GET failed", error);
    return Response.json({ error: "统计数据暂时不可用" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = typeof body.name === "string" ? body.name.trim().slice(0, 30) : "";
    const groupName = typeof body.groupName === "string" ? body.groupName.trim().slice(0, 50) : "";
    const note = typeof body.note === "string" ? body.note.trim().slice(0, 200) : "";
    const slots = Array.isArray(body.slots) ? [...new Set(body.slots.filter(validSlot))].sort() : [];
    if (!name || !slots.length) return Response.json({ error: "请填写姓名并选择时间" }, { status: 400 });
    const db = getDb();
    const requestedId = typeof body.id === "string" ? body.id : "";
    const requestedToken = typeof body.editToken === "string" ? body.editToken : "";
    const existing = requestedId ? await db.select().from(responses).where(eq(responses.id, requestedId)).limit(1) : [];
    if (existing[0]) {
      if (!requestedToken || await hashToken(requestedToken) !== existing[0].editTokenHash) return Response.json({ error: "edit token mismatch" }, { status: 403 });
      const [updated] = await db.update(responses).set({ name, groupName, note, slotsJson: JSON.stringify(slots), updatedAt: new Date().toISOString() }).where(eq(responses.id, requestedId)).returning();
      return Response.json({ response: publicRow(updated), editToken: requestedToken });
    }
    const id = crypto.randomUUID();
    const editToken = `${crypto.randomUUID()}${crypto.randomUUID()}`;
    const [created] = await db.insert(responses).values({ id, editTokenHash: await hashToken(editToken), name, groupName, note, slotsJson: JSON.stringify(slots), updatedAt: new Date().toISOString() }).returning();
    return Response.json({ response: publicRow(created), editToken }, { status: 201 });
  } catch (error) {
    console.error("responses POST failed", error);
    return Response.json({ error: "保存失败，请稍后重试" }, { status: 500 });
  }
}
