import { sql } from "drizzle-orm";
import { text, sqliteTable } from "drizzle-orm/sqlite-core";

export const responses = sqliteTable("responses", {
  id: text("id").primaryKey(),
  editTokenHash: text("edit_token_hash").notNull(),
  name: text("name").notNull(),
  groupName: text("group_name").notNull().default(""),
  note: text("note").notNull().default(""),
  slotsJson: text("slots_json").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
