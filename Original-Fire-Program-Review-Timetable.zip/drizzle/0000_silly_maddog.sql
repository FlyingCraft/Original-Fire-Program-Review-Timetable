CREATE TABLE `responses` (
	`id` text PRIMARY KEY NOT NULL,
	`edit_token_hash` text NOT NULL,
	`name` text NOT NULL,
	`group_name` text DEFAULT '' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`slots_json` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
